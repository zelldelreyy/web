<?php
// KONFIGURASI KONEKSI MYSQL
// GANTI JIKA USER / PASSWORD / NAMA DB KAMU BERBEDA
$host = 'localhost';
$user = 'root';      // default XAMPP
$pass = '';          // default XAMPP
$db   = 'portfolio_db';

$koneksi = mysqli_connect($host, $user, $pass, $db);

if (!$koneksi) {
    die('Koneksi gagal: ' . mysqli_connect_error());
}
?>
